<?php

class Sales_Model extends MY_Model
{


}