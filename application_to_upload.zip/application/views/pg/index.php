
      <!-- Main Content -->
      <div class="main-content">
        <section class="section">
     
              <div class="row">
                    <div class="col-md-6 bg-white">
                      <h4 class=" p-2">Dashboard</h4>
                    </div>
                  <div class="col-md-6 bg-white text-right ">
                    <div class="p-2">date
                    <button class="btn btn-danger d-none check_btn"><i class="fas fa-sign-out-alt"></i> Checkout</button>
                     <button class="btn btn-success check_btn "><i class="fas fa-sign-in-alt"></i> Checkin</button>
                   </div>
                  </div>
              </div>

          <div class="row mt-4">
           
            <div class="col-lg-6 col-md-6 col-sm-12">
              <div class="card card-statistic-2">
                <div class="row">
                 <div class="col-md-3">
                   <div class="card-icon shadow-primary bg-primary">
                      <i class="fas fa-tasks"></i>
                  </div>
                 </div>
                 <div class="col-md-9">
                    <div class="card-wrap text-center">
                      <div class="card-header">
                        <h4>0</h4>
                      </div>
                      <div class="card-body">
                       Open Tickets<br>
                    <span><a href="">More Info <i class="fas fa-arrow-circle-right"></i></a></span>
                      </div>
                    </div>
                 </div>
               </div>
              
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12">
              <div class="card card-statistic-2">
               <div class="row">
                 <div class="col-md-3">
                   <div class="card-icon shadow-primary bg-primary">
                  <i class="fas fa-ticket-alt"></i>
                  </div>
                 </div>
                 <div class="col-md-9">
                    <div class="card-wrap text-center">
                      <div class="card-header">
                        <h4>0</h4>
                      </div>
                      <div class="card-body">
                       Open Tickets<br>
                    <span><a href="">More Info <i class="fas fa-arrow-circle-right"></i></a></span>
                      </div>
                    </div>
                 </div>
               </div>
                
             
              </div>
            </div>
          </div>
           <div class="row">
           
            <div class="col-lg-6 col-md-6 col-sm-12">
              <div class="card card-statistic-2">
               
                <div class="row">
                 <div class="col-md-3">
                   <div class="card-icon shadow-primary bg-primary">
                   <i class="fas fa-bug"></i>
                  </div>
                </div>
                <div class="col-md-9">
                    <div class="card-wrap text-center">
                      <div class="card-header">
                        <h4>0</h4>
                      </div>
                      <div class="card-body">
                       In Progress Projects<br>
                    <span><a href="">More Info <i class="fas fa-arrow-circle-right"></i></a></span>
                      </div>
                    </div>
                 </div>
               </div>
               
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12">
              <div class="card card-statistic-2">
               <div class="row">
                 <div class="col-md-3">
                   <div class="card-icon shadow-primary bg-primary">
                     <i class="far fa-folder-open"></i>
                  </div>
                 </div>
                 <div class="col-md-9">
                    <div class="card-wrap text-center">
                      <div class="card-header">
                        <h4>0</h4>
                      </div>
                      <div class="card-body">
                       In Progress Projects<br>
                    <span><a href="">More Info <i class="fas fa-arrow-circle-right"></i></a></span>
                      </div>
                    </div>
                 </div>
               </div>
                
             
              </div>
            </div>
          </div>
          <div class="row mt-4">
            <div class="col-lg-12">
              <div class="card">
               <!--  <div class="card-header">
                  <h4>Budget vs Sales</h4>
                </div> -->
             <!--    <div class="card-body">
                  <canvas id="myChart" height="158"></canvas>
                </div> -->
                <ul class="nav nav-tabs nav-justified md-tabs indigo" id="myTabJust" role="tablist">
                  <li class="nav-item">
                    <a class="nav-link active" id="home-tab-just" data-toggle="tab" href="#home-just" role="tab" aria-controls="home-just"
                      aria-selected="true">Overdue Projects(8)</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="profile-tab-just" data-toggle="tab" href="#profile-just" role="tab" aria-controls="profile-just"
                      aria-selected="false">Overdue Tasks(10)</a>
                  </li>
                  <li class="nav-item">
                    <a class="nav-link" id="contact-tab-just" data-toggle="tab" href="#contact-just" role="tab" aria-controls="contact-just"
                      aria-selected="false">Overdue Invoice</a>
                  </li>
                </ul>
                <div class="tab-content card pt-5" id="myTabContentJust">
                  <div class="tab-pane fade show active px-4" id="home-just" role="tabpanel" aria-labelledby="home-tab-just">
                   <table id="example" class="display nowrap" style="width:100%">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Position</th>
                                <th>Office</th>
                                <th>Age</th>
                                <th>Start date</th>
                                <th>Salary</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Tiger Nixon</td>
                                <td>System Architect</td>
                                <td>Edinburgh</td>
                                <td>61</td>
                                <td>2011/04/25</td>
                                <td>$320,800</td>
                            </tr>
                            
                            <tr>
                                <td>Shad Decker</td>
                                <td>Regional Director</td>
                                <td>Edinburgh</td>
                                <td>51</td>
                                <td>2008/11/13</td>
                                <td>$183,000</td>
                            </tr>
                            <tr>
                                <td>Michael Bruce</td>
                                <td>Javascript Developer</td>
                                <td>Singapore</td>
                                <td>29</td>
                                <td>2011/06/27</td>
                                <td>$183,000</td>
                            </tr>
                            <tr>
                                <td>Donna Snider</td>
                                <td>Customer Support</td>
                                <td>New York</td>
                                <td>27</td>
                                <td>2011/01/25</td>
                                <td>$112,000</td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th>Name</th>
                                <th>Position</th>
                                <th>Office</th>
                                <th>Age</th>
                                <th>Start date</th>
                                <th>Salary</th>
                            </tr>
                        </tfoot>
                    </table>
                  </div>
                  <div class="tab-pane fade px-4" id="profile-just" role="tabpanel" aria-labelledby="profile-tab-just">
                   <table id="example12" class="table table-striped display nowrap" style="width:100%">
                        <thead class="border">
                            <tr>
                                <th>Name</th>
                                <th>Position</th>
                                <th>Office</th>
                                <th>Age</th>
                                <th>Start date</th>
                                <th>Salary</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Tiger Nixon</td>
                                <td>System Architect</td>
                                <td>Edinburgh</td>
                                <td>61</td>
                                <td>2011/04/25</td>
                                <td>$320,800</td>
                            </tr>
                            
                            <tr>
                                <td>Shad Decker</td>
                                <td>Regional Director</td>
                                <td>Edinburgh</td>
                                <td>51</td>
                                <td>2008/11/13</td>
                                <td>$183,000</td>
                            </tr>
                            <tr>
                                <td>Michael Bruce</td>
                                <td>Javascript Developer</td>
                                <td>Singapore</td>
                                <td>29</td>
                                <td>2011/06/27</td>
                                <td>$183,000</td>
                            </tr>
                            <tr>
                                <td>Donna Snider</td>
                                <td>Customer Support</td>
                                <td>New York</td>
                                <td>27</td>
                                <td>2011/01/25</td>
                                <td>$112,000</td>
                            </tr>
                        </tbody>
                        <tfoot class="border">
                            <tr>
                                <th>Name</th>
                                <th>Position</th>
                                <th>Office</th>
                                <th>Age</th>
                                <th>Start date</th>
                                <th>Salary</th>
                            </tr>
                        </tfoot>
                    </table>
                  </div>
                  <div class="tab-pane fade px-4" id="contact-just" role="tabpanel" aria-labelledby="contact-tab-just">
                    <p>Etsy mixtape wayfarers, ethical wes anderson tofu before they sold out mcsweeney's organic lomo retro
                      fanny pack lo-fi farm-to-table readymade. Messenger bag gentrify pitchfork tattooed craft beer, iphone
                      skateboard locavore carles etsy salvia banksy hoodie helvetica. DIY synth PBR banksy irony. Leggings
                      gentrify squid 8-bit cred pitchfork. Williamsburg banh mi whatever gluten-free, carles pitchfork
                      biodiesel fixie etsy retro mlkshk vice blog. Scenester cred you probably haven't heard of them, vinyl
                      craft beer blog stumptown. Pitchfork sustainable tofu synth chambray yr.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row mt-4">
            <div class="col-lg-6">
              <div class="card card-height">
                <div class="card-header row border-bottom py-1">
                  <div class="col-md-6">
                    <span><strong>TO DO List</strong></span> | <a href="" >View All</a>
                   </div>
                    <div class="col-md-6 text-right"><button class="btn btn-success rounded-0">Add New</button></div>
                </div>
                <div class="">
                  <table class="table table-striped display nowrap" id="table2">
                 
                      <thead class="">
                       <tr>
                          <th></th>
                         <th>What To Do</th>
                         <th>Status</th>
                         <th>End Date</th>
                       </tr>
                      </thead>
            
                    <tbody>
                        <tr>
                            <td class="sorter"></td>
                            <td>Row 1</td>
                            <td>Record 1</td>
                            <td>Record 1</td>
                        </tr>
                        <tr>
                            <td class="sorter"></td>
                            <td>Row 2</td>
                            <td>Record 2</td>
                            <td>Record 2</td>
                        </tr>
                        <tr>
                            <td class="sorter"></td>
                            <td>Row 3</td>
                            <td>Record 3</td>
                            <td>Recrod 3</td>
                        </tr>
                        <tr>
                            <td class="sorter"></td>
                            <td>Row 4</td>
                            <td>Record 4</td>
                            <td>Record 4</td>
                        </tr>
                        <tr>
                            <td class="sorter"></td>
                            <td>Row 5</td>
                            <td>Record 5</td>
                            <td>Record 5</td>
                        </tr>
                    </tbody>
              <!--       <tfoot>
                        <tr>
                            <td colspan="4">&nbsp;</td>
                        </tr>
                    </tfoot> -->

                  </table>
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="card p-2">
                <div class="card-header row border-bottom py-1">
                  <div class="col-md-6">
                    <span><strong>My Calender</strong></span> 
                   </div>
                    <!-- <div class="col-md-6 text-right"><button class="btn btn-success rounded-0">Add New</button></div> -->
                </div>
              
                <div class="p-2">
                   <div id='calendar'></div>
                </div>
              </div>
            </div>
          </div>
          <div class="row mt-4">
            <div class="col-lg-6">
              <div class="card card-height">
                <div class="card-header row border-bottom py-1">
                  <div class="col-md-6">
                    <span><strong>Announcements</strong></span> 
                   </div>
                    <!-- <div class="col-md-6 text-right"><button class="btn btn-success rounded-0">Add New</button></div> -->
                </div>
              
                <div class="">
                  <ul class="list-unstyled p-4">
                    <li class="row">
                      <div class="col-md-2">
                        <div class="annouce_date_col">
                          <div class="month">June</div>
                          <div class="date">13</div>
                        </div>
                      </div>
                      <div class="col-md-10">
                         <a href=""><h6>Create an external account</h6></a>
                         <span>https://web-nostromo.com/</span>
                         <div class="text-right"><a href="">View Details</a></div>
                      </div>
                    </li>
                  </ul>  
             
                </div>
              </div>
            </div>
            <div class="col-lg-6">
              <div class="card card-height">
                <div class="card-header row border-bottom py-1">
                  <div class="col-md-6">
                    <span><strong>Recent Activities</strong></span> 
                   </div>
                    <!-- <div class="col-md-6 text-right"><button class="btn btn-success rounded-0">Add New</button></div> -->
                </div>
              
                <div class="">
                  <ul class="list-unstyled p-4">
                    <li class="row">
                      <div class="rec_act">
                         <img src="../assets/img/avatar/avatar-1.png" alt="" class="rounded-circle img-fluid">
                      </div>
                      <div>
                          <span><strong>Create an external account</strong>&nbsp; Time</span><br>
                          <div>Updated Profile</div>
                      </div> 
                    
                    </li>
                  </ul>  
             
                </div>
              </div>
            </div>
          </div>
        
          
        </section>
      </div>
      