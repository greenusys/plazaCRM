<?php

$config['protocol'] = 'smtp';
$config['smtp_host'] = "smtp.gmail.com";
$config['smtp_port'] = 465;
$config['smtp_user'] = "greenusysnoida@gmail.com";
$config['smtp_pass'] = "Business123@#$";
$config['mailtype'] = 'html';
$config['charset'] = 'iso-8859-1';
$config['smtp_crypto'] = "ssl";
$config['smtp_timeout'] = '10';
$config['from_user'] = 'Deepak';
